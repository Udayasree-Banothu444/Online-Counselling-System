import java.util.ArrayList;

public class Choices {
    static ArrayList<String> ClgList = new ArrayList<>();
}
